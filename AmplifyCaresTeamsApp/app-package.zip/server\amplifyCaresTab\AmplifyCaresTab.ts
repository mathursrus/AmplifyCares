import { PreventIframe } from "express-msteams-host";

/**
 * Used as place holder for the decorators
 */
@PreventIframe("/amplifyCaresTab/index.html")
export class AmplifyCaresTab {
}
